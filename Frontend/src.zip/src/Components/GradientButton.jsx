const GradientButton = ({ children }) => (
    <button className="relative group w-full mt-2">
        {/* Hover Glow Effect */}
        <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl blur opacity-30 group-hover:opacity-60 transition duration-300"></div>
        {/* Button Itself */}
        <div className="relative w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center font-bold text-white hover:scale-[1.02] transition-transform duration-200">
            {children}
        </div>
    </button>
);

export default GradientButton;