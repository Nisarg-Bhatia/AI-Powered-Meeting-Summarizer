import React from 'react';
import { Link } from 'react-router-dom';

const AuthLayout = ({ children, title, subtitle }) => {
  return (
    // Main Container with dark background and overflow hidden for glow effects
    <div className="min-h-screen bg-[#050505] text-white flex items-center justify-center relative overflow-hidden p-4">
      
      {/* === BACKGROUND GLOWS === */}
      {/* Top left purple glow */}
      <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-purple-900/30 rounded-full blur-[120px] -z-10 animate-pulse-slow"></div>
      {/* Bottom right cyan glow */}
      <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-cyan-900/30 rounded-full blur-[120px] -z-10 animate-pulse-slow" style={{animationDelay: '2s'}}></div>
      
      {/* === MAIN CARD CONTAINER === */}
      <div className="w-full max-w-md relative z-10">
        
        {/* Brand Logo Header */}
        <div className="text-center mb-8">
            {/* Replace to="/" with your homepage route */}
            <Link to="/" className="inline-block text-3xl font-extrabold tracking-tight">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-600">MeetSmart</span>
                <span className="text-gray-100">AI</span>
            </Link>
        </div>

        {/* Glassmorphism Form Card */}
        <div className="bg-[#0a0a0a]/80 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden">
          
          {/* Subtle top gradient border line */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500/50 via-blue-500/50 to-purple-500/50 opacity-50"></div>

          {/* Form Header */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-2">{title}</h2>
            <p className="text-gray-400 text-sm">{subtitle}</p>
          </div>

          {/* The actual form content goes here */}
          {children}

        </div>
      </div>
    </div>
  );
};

export default AuthLayout;